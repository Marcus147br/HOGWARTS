<?php

declare(strict_types=1);

namespace App\Model;

final class Example
{
    public function sayHello(): string
    {
        return "Hi, OOP World in PHP!\n";
    }
}